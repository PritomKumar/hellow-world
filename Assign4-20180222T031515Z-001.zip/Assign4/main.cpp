#include <iostream>
#include <fstream>
#include <cmath>
#include <queue>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int **adjacencyMatrix;
int **qMatrix;
int *t, *prev, *cost;
int numberOfVertex , line ,query;
int sr;

void makeAdjacencyMatrix()
{
	adjacencyMatrix = new int *[numberOfVertex];
	for(int i=0; i<numberOfVertex; i++)
	{
		adjacencyMatrix[i] = new int [numberOfVertex];
	}
}

void destroyAdjacencyMatrix()
{
	for(int i=0; i<numberOfVertex; i++)
	{
		delete [] adjacencyMatrix[i];
	}
	delete [] adjacencyMatrix;

}
void initializeAdjacencyMatrix(){

	for(int i=0 ; i< numberOfVertex ; i++){
		for(int j=0 ; j< numberOfVertex ; j++){
			adjacencyMatrix[i][j] = 0;
		}
	}
}



void initialize(){

    for(int i=0 ; i < numberOfVertex ; i++){
        t[i] = 0;
        cost[i] = 999999;
        prev[i] = -1 ; //-1 for NULL

    }
    cost[sr] = 0;
}

int extractMin(){

    int mini = 999999;
    int miniNode = -1;

    for(int i=0; i<numberOfVertex ; i++){
        if(t[i] == 0 && cost[i] < mini){
            miniNode = i;
            mini = cost[i];
        }
    }
    t[miniNode] = 1;
    return miniNode;
}

void relax(int u , int v){

    if(adjacencyMatrix[u][v] < cost[v]){

        cost[v] = adjacencyMatrix[u][v];
        prev[v] = u;
    }
}

void findPath(int source,int des){

	int s,d;

	s = des-1;
	d = source-1;

	int path=s ;

	int maxi = 0;
	while(1){

		if(cost[path] > maxi ){
			maxi = cost[path];
		}
		path = prev[s];
		s = path;
		//cout << path+1 << " " ;
		if (path == d) break;
	}
	if(maxi==0) cout << "no path" <<endl;
	else cout <<maxi <<endl;
}

int prim(){

    initialize();

    for (int i=0 ; i< numberOfVertex ; i++){
         int  u = extractMin();
		 if(u==-1) continue;
         for(int v=0; v< numberOfVertex ; v++){

            if(adjacencyMatrix[u][v] > 0 && t[v]==0 && adjacencyMatrix[u][v] < cost[v]){
                cost[v] = adjacencyMatrix[u][v];
                prev[v] = u;
            }
         }
    }
    return 0;

}

void printResult()
{
	string arr = "ABCDEFGH";

	for(int i=0; i<numberOfVertex; i++)
    {
        for(int j=0; j<numberOfVertex; j++)
        {
            cout << adjacencyMatrix[i][j] << " ";
        }
        cout <<endl;
    }

    for(int i=0; i<query ; i++){
		cout << qMatrix[i][0] << " " << qMatrix[i][1] <<endl ;
    }
	cout 	<< "Point" << "\t"
			<< "Tree" << "\t"
			<< "Cost" << "\t"
			<< "Prev" << endl;

	for(int i=0; i<numberOfVertex; i++)
	{
		cout 	<< arr[i] << "\t"
                << t[i] << "\t"
                << cost[i] << "\t"
				<< arr[prev[i]] << endl;
	}
	//findPath(0, 7);
}

int MST(){

    int sum=0;
    for(int i=0 ; i< numberOfVertex ; i++){
        sum = sum + cost[i];
    }
    return sum;
}

bool openFile(char *fileName)
{
	ifstream iFile;
	iFile.open(fileName);
	if(iFile.is_open())
	{
		int counter1=1;
		while (iFile >> numberOfVertex >> line >> query ){

			makeAdjacencyMatrix();

			initializeAdjacencyMatrix();

			t = new int [numberOfVertex];
			prev = new int [numberOfVertex];
			cost = new int [numberOfVertex];
			qMatrix = new int *[query];

			for(int i=0;i<query;i++)
			{
				qMatrix[i] = new int [2];
			}

			int u,v,cost;
			for (int k=0 ; k < line ; k++){
				iFile >> u >> v >> cost;

				adjacencyMatrix[u-1][v-1] = cost;
				adjacencyMatrix[v-1][u-1] = cost;
			}

			for(int i =0 ;i < query ; i++){
				iFile >> qMatrix[i][0] >> qMatrix[i][1];
			}
			cout << "Case #" << counter1 <<endl;
			for (int i=0;i<query ;i++){

				sr = qMatrix[i][0] -1;
				int lk= prim();
				if(lk ==-1) cout << "no path" <<endl;
				//printResult();
				if(lk!=-1) findPath(qMatrix[i][0] , qMatrix[i][1]);
			}
			counter1++;
		}
		iFile.close();

		return true;
	}
	else
	{
		cout << "could not open input file" << endl;
		return false;
	}

}
int main ()
{
	if(!openFile("adj.txt")) return -1;

    int mst = MST();

    //cout << "\nMST is : "<< mst <<endl;
	destroyAdjacencyMatrix();
	return 0;
}

